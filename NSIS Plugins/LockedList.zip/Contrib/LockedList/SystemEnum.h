#ifndef SYSTEMENUM_H_INCLUDED
#define SYSTEMENUM_H_INCLUDED

#ifndef WINNT
#error You need Windows NT to use this source code. Use /D "WINNT" compiler switch.
#endif

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef GetWindowLongPtr
#define GetWindowLongPtr GetWindowLong
#endif

#ifndef NT_SUCCESS
#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)
#endif

#ifndef LIST_MODULES_ALL
#define LIST_MODULES_ALL 0x03
#endif

#define SYSTEMENUM_ARRAY_SIZE 256
#define SYSTEMENUM_CAPTION_SIZE 1024

struct FILE_INFORMATION
{
  DWORD  ProcessId;
  TCHAR  FullPath[MAX_PATH];
  PTCHAR ProcessDescription;
  HWND   ProcessHWND;
  TCHAR  ProcessFullPath[MAX_PATH];
  UINT   FileNumber;
  UINT   TotalFiles;
};

struct ENUM_OPTIONS
{
  LPARAM lParam;
  BOOL GetWindowCaption;
};

typedef BOOL (CALLBACK*ENUM_FILES)(FILE_INFORMATION, LPARAM);
typedef BOOL (CALLBACK*ENUM_PROCESS_IDS)(DWORD, LPARAM);
typedef BOOL (CALLBACK*ENUM_APPLICATIONS)(FILE_INFORMATION, LPARAM);

BOOL WINAPI EnumSystemHandles(ENUM_FILES, ENUM_OPTIONS*);
BOOL WINAPI EnumSystemProcesses(ENUM_FILES, ENUM_OPTIONS*, BOOL);
BOOL WINAPI EnumProcessIds(ENUM_PROCESS_IDS, ENUM_OPTIONS*);
BOOL WINAPI EnumApplications(ENUM_APPLICATIONS, ENUM_OPTIONS*);

ULONG WINAPI GetSystemHandlesCount();
UINT WINAPI GetSystemModulesCount();
UINT WINAPI GetProcessIdsCount();
UINT WINAPI GetApplicationsCount();

BOOL IsSystemProcess(DWORD);
void MyZeroMemory(PVOID, UINT);
void GetFileFromPath(const PTCHAR, size_t, PTCHAR, size_t);
void FinishEnumeratingNow();
BOOL EndsWith(const PTCHAR, const PTCHAR);
BOOL StartsWith(const PTCHAR, const PTCHAR);

#endif