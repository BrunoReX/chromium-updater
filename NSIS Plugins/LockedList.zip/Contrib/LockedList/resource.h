//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LockedList.rc
//
#define IDC_NEXT                        1
#define IDD_DIALOG                      101
#define IDI_INSTALLERICON               103
#define IDC_BLACKRECT                   1018
#define IDC_HEADING                     1211
#define IDC_LIST                        1212
#define IDC_PROGRESS                    1213

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1226
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
